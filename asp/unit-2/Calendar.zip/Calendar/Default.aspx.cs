﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Calendar1.Visible = false;    
        }
        

        Literal1.Text = "DateTime.Now.ToString(); = " + DateTime.Now.ToString() + "</br>";
        Literal1.Text += "DateTime.Now.ToLongDateString(); = " + DateTime.Now.ToLongDateString() + "</br>";
        Literal1.Text += "DateTime.Now.ToShortDateString(); = " + DateTime.Now.ToShortDateString() + "</br>";
        Literal1.Text += "DateTime.Now.ToLongTimeString(); = " + DateTime.Now.ToLongTimeString() + "</br>";
        Literal1.Text += "DateTime.Now.ToShortTimeString(); = " + DateTime.Now.ToShortTimeString() + "</br></br>";

        Literal1.Text += "DateTime.Now.ToString(\"d\"); = " + DateTime.Now.ToString("d") + "</br>";
        Literal1.Text += "DateTime.Now.ToString(\"D\"); = " + DateTime.Now.ToString("D") + "</br>";
        Literal1.Text += "DateTime.Now.ToString(\"dd/MM/yyyy\"); = " + DateTime.Now.ToString("dd/MM/yyyy") + "</br>";
        Literal1.Text += "DateTime.Now.ToString(\"dd/MMMM/yyyy\"); = " + DateTime.Now.ToString("dd/MMMM/yyyy") + "</br>";
        Literal1.Text += "DateTime.Now.ToString(\"dd/MMMM/yy\"); = " + DateTime.Now.ToString("dd/MMMM/yy") + "</br>";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = Calendar1.SelectedDate.ToString("dd/MM/yyyy");
    }
}