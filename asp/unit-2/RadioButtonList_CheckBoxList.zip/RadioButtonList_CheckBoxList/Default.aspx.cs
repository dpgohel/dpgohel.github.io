﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Literal1.Text = "Text=" + RadioButtonList1.SelectedItem.Text + "</br>";
        Literal1.Text += "Value=" + RadioButtonList1.SelectedItem.Value + "</br>";
        Literal1.Text += "Index=" + RadioButtonList1.SelectedIndex.ToString() + "</br>";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        RadioButtonList1.ClearSelection();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        foreach (ListItem li in CheckBoxList1.Items)
        {
            if (li.Selected)
            {
                Literal2.Text += "Text=" + li.Text + "</br>";
                Literal2.Text += "Value=" + li.Value + "</br>";
                Literal2.Text += "Index=" + CheckBoxList1.Items.IndexOf(li).ToString() + "</br>-----------------</br>";
            }
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        CheckBoxList1.ClearSelection();
    }
}