﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BulletedList4_Click(object sender, BulletedListEventArgs e)
    {
        ListItem li = BulletedList4.Items[e.Index];
        Literal1.Text = li.Text + "-" + li.Value.ToString();
    }
}