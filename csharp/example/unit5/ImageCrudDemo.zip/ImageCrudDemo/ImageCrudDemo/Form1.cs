﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ImageCrudDemo
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        int id;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\divyesh\documents\visual studio 2010\Projects\ImageCrudDemo\ImageCrudDemo\Database1.mdf;Integrated Security=True;User Instance=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [user] ([name], [image]) VALUES (@name, @image)", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@image", SaveImage());
            con.Open();
            int s=cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                pictureBox1.Image = null;
                MessageBox.Show("User Insert Successfully!");
            }
            else
            {
                MessageBox.Show("Eror!");
            }
            Print();
        }

        private byte[] SaveImage()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.GetBuffer();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "Select Image";
            ofd.Filter = "Image File | *.png;*.jpg;*.jpeg;*.bmp;*.gif";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(ofd.FileName);
                
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {
            SqlDataAdapter adpt = new SqlDataAdapter("SELECT * FROM [user]", con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.RowTemplate.Height = 50;
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            pictureBox1.Image = GetImage((byte[])dataGridView1.SelectedRows[0].Cells[2].Value);
        }

        private Image GetImage(byte[] p)
        {
            MemoryStream ms = new MemoryStream(p);
            return Image.FromStream(ms);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("UPDATE [user] SET [name]=@name, [image]=@image WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@image", SaveImage());
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                pictureBox1.Image = null;
                MessageBox.Show("User Update Successfully!");
            }
            else
            {
                MessageBox.Show("Eror!");
            }
            Print();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM [user] WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                pictureBox1.Image = null;
                MessageBox.Show("User Delete Successfully!");
            }
            else
            {
                MessageBox.Show("Eror!");
            }
            Print();
        }
    }
}
