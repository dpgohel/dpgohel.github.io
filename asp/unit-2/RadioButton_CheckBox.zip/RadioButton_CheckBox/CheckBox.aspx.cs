﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CheckBox : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Text = "You select ";
        Label4.Text = "You are ";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (CheckBox1.Checked)
        {
            Label3.Text += "Gujarati,";
        }
        if (CheckBox2.Checked)
        {
            Label3.Text += "Hindi,";
        }
        if (CheckBox3.Checked)
        {
            Label3.Text += "English,";
        }
    }
    protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox4.Checked)
        {
            Label4.Text += "Agree";
        }
        else
        {
            Label4.Text += "not Agree";
        }
            
    }
}