﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MessageBoxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Action information for users");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBox.Show(msg, title);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBoxButtons button = MessageBoxButtons.AbortRetryIgnore;
            DialogResult res = MessageBox.Show(msg, title,button);
            if (res == DialogResult.Abort)
                label1.Text = "Abort";
            else if (res == DialogResult.Retry)
                label1.Text = "Retry";
            else
                label1.Text = "Ignore";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBoxButtons button = MessageBoxButtons.YesNoCancel;
            DialogResult res = MessageBox.Show(msg, title, button, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
                label1.Text = "Yes";
            else if (res == DialogResult.No)
                label1.Text = "No";
            else
                this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBoxButtons button = MessageBoxButtons.YesNoCancel;
            DialogResult res = MessageBox.Show(msg, title, button, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (res == DialogResult.Yes)
                label1.Text = "Yes";
            else if (res == DialogResult.No)
                label1.Text = "No";
            else
                this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBoxButtons button = MessageBoxButtons.YesNoCancel;
            DialogResult res = MessageBox.Show(msg, title, button, MessageBoxIcon.Question, 0, MessageBoxOptions.RightAlign);
            if (res == DialogResult.Yes)
                label1.Text = "Yes";
            else if (res == DialogResult.No)
                label1.Text = "No";
            else
                this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string msg = "Action information for users";
            string title = "Messagebox Demo";
            MessageBoxButtons button = MessageBoxButtons.YesNoCancel;
            DialogResult res = MessageBox.Show(msg, title, button, MessageBoxIcon.Question, 0, MessageBoxOptions.RightAlign, "helpfile.chm");
            if (res == DialogResult.Yes)
                label1.Text = "Yes";
            else if (res == DialogResult.No)
                label1.Text = "No";
            else
                this.Close();
        }
    }
}
