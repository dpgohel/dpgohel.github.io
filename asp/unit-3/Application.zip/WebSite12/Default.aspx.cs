﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Application["Name"] = TextBox1.Text;
        Application["Email"] = TextBox2.Text;
        Session["Name"] = TextBox3.Text;
        Session["Email"] = TextBox4.Text;
        Response.Redirect("~/Default2.aspx");
    }
}