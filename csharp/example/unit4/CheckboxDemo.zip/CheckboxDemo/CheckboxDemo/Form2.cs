﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckboxDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            if (checkBox1.Checked == true)
                label2.Text += checkBox1.Text+", ";
            if (checkBox2.Checked == true)
                label2.Text += checkBox2.Text + ", ";
            if (checkBox3.Checked == true)
                label2.Text += checkBox3.Text + ", ";
            if (checkBox4.Checked == true)
                label2.Text += checkBox4.Text + ", ";
            if (checkBox5.Checked == true)
                label2.Text += checkBox5.Text + ", ";
            if (checkBox6.Checked == true)
                label2.Text += checkBox6.Text + ", ";
            if (checkBox7.Checked == true)
                label2.Text += checkBox7.Text + ", ";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = "";
            if (checkBox8.Checked == true)
                label3.Text += checkBox8.Text + ", ";
            if (checkBox9.Checked == true)
                label3.Text += checkBox9.Text + ", ";
            if (checkBox10.Checked == true)
                label3.Text += checkBox10.Text + ", ";
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox11.Checked == true)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = true;
                checkBox3.Checked = true;
                checkBox4.Checked = true;
                checkBox5.Checked = true;
                checkBox6.Checked = true;
                checkBox7.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
            }
        }
    }
}
