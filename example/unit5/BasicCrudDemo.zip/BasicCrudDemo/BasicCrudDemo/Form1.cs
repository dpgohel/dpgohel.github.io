﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BasicCrudDemo
{
    public partial class Form1 : Form
    {
        int id;
        SqlConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\divyesh\documents\visual studio 2010\Projects\BasicCrudDemo\BasicCrudDemo\Database1.mdf;Integrated Security=True;User Instance=True");
            print();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into stud (name, address) values (@name, @address)", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@address", textBox2.Text);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                textBox2.Clear();
                MessageBox.Show("Insert Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            print();
        }
        public void print()
        {
            SqlDataAdapter adpt = new SqlDataAdapter("select * from stud", con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            print();
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("UPDATE [stud] set [name]=@name, [address]=@address WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@address", textBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s=cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                textBox2.Clear();
                MessageBox.Show("Update Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            print();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM [stud] WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                textBox2.Clear();
                MessageBox.Show("Delete Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            print();
        }
    }
}
