﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie c2 = Request.Cookies["UserInfo"];
        if (c2!= null)
        {
            Literal1.Text = c2["Name"];
            Literal2.Text = c2["Email"];    
        }
        else
        {
            //Response.Redirect("~/Default.aspx");
            Literal3.Text = "Cookies not available";
        }
    }
}