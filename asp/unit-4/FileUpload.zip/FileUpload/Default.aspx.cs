﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        //DeleteCommand="DELETE FROM [products] WHERE [id] = @id" 
        //InsertCommand="INSERT INTO [products] ([name], [price], [image]) VALUES (@name, @price, @image)" 
        //ProviderName="<%$ ConnectionStrings:DatabaseConnectionString1.ProviderName %>" 
        //SelectCommand="SELECT [id], [name], [price], [image] FROM [products]" 
        //UpdateCommand="UPDATE [products] SET [name] = @name, [price] = @price, [image] = @image WHERE [id] = @id">

        con = new SqlConnection(ConfigurationManager.ConnectionStrings["DatabaseConnectionString1"].ConnectionString);
        print();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/uploads/" + FileUpload1.FileName));
            SqlCommand cmd = new SqlCommand("INSERT INTO [products] ([name], [price], [image]) VALUES (@name, @price, @image)", con);
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@price", TextBox2.Text);
            cmd.Parameters.AddWithValue("@image", FileUpload1.FileName);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                Literal1.Text = "Data Inserted Successfully!";
                TextBox1.Text = string.Empty;
                TextBox2.Text = string.Empty;
                FileUpload1.Attributes.Clear();
                print();
            }
            else
            {
                Literal1.Text = "Please fill all details!";
            }
        }
        else
        {
            Literal1.Text = "Please select Image or file!";
        }
    }
    public void print()
    {
        SqlDataAdapter adpt = new SqlDataAdapter("SELECT [id], [name], [price], [image] FROM [products]", con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        SqlCommand cmd = new SqlCommand("DELETE FROM [products] WHERE [id] = @id", con);
        cmd.Parameters.AddWithValue("@id", btn.CommandArgument);
        con.Open();
        int s = cmd.ExecuteNonQuery();
        con.Close();
        if (s == 1)
        {
            Literal1.Text = "Data Deleted Successfully!";
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            FileUpload1.Attributes.Clear();
            print();
        }
        else
        {
            Literal1.Text = "Error!";
        }
    }
}