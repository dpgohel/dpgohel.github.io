﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ComboboxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = comboBox1.GetItemText(comboBox1.SelectedItem);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (comboBox1.Items.Contains(textBox1.Text))
                {
                    MessageBox.Show("Color already exist");
                }
                else
                {
                    comboBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                } 
            }
            else
            {
                MessageBox.Show("Please add color name");
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total itms = " + comboBox1.Items.Count);
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Remove(comboBox1.SelectedItem);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            comboBox1.Items.RemoveAt(comboBox1.SelectedIndex);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
        }
    }
}
