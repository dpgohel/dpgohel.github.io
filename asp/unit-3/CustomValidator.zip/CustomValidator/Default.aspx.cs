﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            Literal2.Text = "Number is " + TextBox1.Text;    
        }
        else
        {
            Literal2.Text = "Error!";
        }
        
    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (args.Value == "")
        {
            args.IsValid = false;
        }
        else
        {
            //int no = Convert.ToInt32(args.Value);
            int no;
            bool IsNumber = int.TryParse(args.Value, out no);
            if (IsNumber && no % 2 == 0 && no > 0)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }
        }
    }
}