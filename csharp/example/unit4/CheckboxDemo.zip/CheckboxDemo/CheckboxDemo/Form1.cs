﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckboxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "";
            if (checkBox1.Checked == true)
            {
                label2.Text += checkBox1.Text + ", ";
            }
            if (checkBox2.Checked == true)
            {
                label2.Text += checkBox2.Text + ", ";
            }
            if (checkBox3.Checked == true)
            {
                label2.Text += checkBox3.Text + ", ";
            }
            if (checkBox4.Checked == true)
            {
                label2.Text += checkBox4.Text + ", ";
            }
            if (checkBox5.Checked == true)
            {
                label2.Text += checkBox5.Text + ", ";
            }
            if (checkBox6.Checked == true)
            {
                label2.Text += checkBox6.Text + ", ";
            }
            if (checkBox7.Checked == true)
            {
                label2.Text += checkBox7.Text + ", ";
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked == true)
            {
                button1.Enabled = true;
                MessageBox.Show("Form is Enable");
            }
            else
            {
                button1.Enabled = false;
                MessageBox.Show("Form is Disable");
            }
        }
    }
}
