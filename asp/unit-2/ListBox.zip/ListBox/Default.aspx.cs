﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Literal1.Text = "Text=" + ListBox1.SelectedItem.Text + "</br>";
        Literal1.Text += "Value=" + ListBox1.SelectedItem.Value + "</br>";
        Literal1.Text += "Text=" + ListBox1.SelectedIndex.ToString() + "</br>";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        foreach (ListItem li in ListBox2.Items)
        {
            if (li.Selected)
            {
                Literal2.Text += "Text=" + li.Text + "</br>";
                Literal2.Text += "Value=" + li.Value + "</br>";
                Literal2.Text += "Text=" + ListBox1.Items.IndexOf(li).ToString() + "</br>-------------------------</br>";
            }
        }
    }
    protected void ListBox3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ListBox3.SelectedItem != null) // ListBox3.SelectedIndex != -1 
        {
            Literal3.Text = "Text=" + ListBox3.SelectedItem.Text + "</br>";
            Literal3.Text += "Value=" + ListBox3.SelectedItem.Value + "</br>";
            Literal3.Text += "Text=" + ListBox3.SelectedIndex.ToString() + "</br>";    
        }
    }
}