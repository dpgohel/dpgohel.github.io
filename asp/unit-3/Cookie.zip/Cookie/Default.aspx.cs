﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        HttpCookie c1 = new HttpCookie("UserInfo");
        c1["Name"] = TextBox1.Text;
        c1["Email"] = TextBox2.Text;
        Response.Cookies.Add(c1);
        c1.Expires = DateTime.Now.AddDays(30);
        Response.Redirect("~/Default2.aspx");
    }
}