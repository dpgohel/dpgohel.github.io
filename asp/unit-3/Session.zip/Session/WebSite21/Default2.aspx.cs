﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Name"]!=null && Session["Email"]!=null)
        {
            Literal1.Text = Session["Name"].ToString();
            Literal2.Text = Session["Email"].ToString();    
        }
        else
        {
            Literal3.Text = "Session not stored";
        }
        
    }
}