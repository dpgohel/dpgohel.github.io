﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RadioButton : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButton1.Checked)
        {
            Response.Write("You select Male option");    
        }
        else if (RadioButton2.Checked)
        {
            Response.Write("You select Female option");    
        }
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        Response.Write("You select Red color");
    }
    protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
    {
        Response.Write("You select Green color");
    }
}