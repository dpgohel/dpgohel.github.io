﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CommonControlBinding
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\divyesh\documents\visual studio 2010\Projects\CommonControlBinding\CommonControlBinding\Database1.mdf;Integrated Security=True;User Instance=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [city] ([city_name]) VALUES (@city_name)", con);
            cmd.Parameters.AddWithValue("@city_name", textBox1.Text);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                Print();
                MessageBox.Show("City Insert Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {
            SqlDataAdapter adpt = new SqlDataAdapter("SELECT * FROM [city]", con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
            listBox1.Items.Clear();
            foreach (DataRow row in dt.Rows)
            {
                listBox1.Items.Add(row["city_name"].ToString());
            }
        }
    }
}
