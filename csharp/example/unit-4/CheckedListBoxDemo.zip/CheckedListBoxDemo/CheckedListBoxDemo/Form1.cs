﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckedListBoxDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (string s in checkedListBox1.CheckedItems)
            {
                label2.Text += s + ", ";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (checkedListBox1.Items.Contains(textBox1.Text))
                {
                    MessageBox.Show("Color already exist");
                }
                else
                {
                    checkedListBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please enter color name");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total items = " + checkedListBox1.Items.Count);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            checkedListBox1.Sorted = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.Remove(checkedListBox1.SelectedItem);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.RemoveAt(checkedListBox1.SelectedIndex);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            checkedListBox1.Items.Clear();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string s in checkedListBox1.CheckedItems)
            {
                listBox1.Items.Add(s);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            for (int i = 0; i < checkedListBox1.CheckedIndices.Count; i++)
            {
                listBox2.Items.Add(checkedListBox1.CheckedIndices[i]);
            }
        }
    }
}
