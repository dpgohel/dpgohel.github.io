﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WinformClassDemo
{
    public partial class Form1 : Form
    {
        Form2 f2 = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            f2.TopMost = true;
            f2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            f2.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "Form -1 Loading...";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            f2.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            f2.Close();
        }

    }
}
