﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CommonControlCrudDemo
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        int id;
        public Form1()
        {
            InitializeComponent();
            con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\divyesh\documents\visual studio 2010\Projects\CommonControlCrudDemo\CommonControlCrudDemo\Database1.mdf;Integrated Security=True;User Instance=True");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO [users] ([name], [cast], [age]) VALUES (@name, @cast, @age)", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@cast", comboBox1.SelectedItem);
            cmd.Parameters.AddWithValue("@age", numericUpDown1.Value);
            con.Open();
            int s=cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                comboBox1.SelectedIndex = -1;
                numericUpDown1.Value = 0;
                MessageBox.Show("Data Insert Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            Print();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {
            SqlDataAdapter adpt = new SqlDataAdapter("SELECT * FROM [users]", con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            numericUpDown1.Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[3].Value);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("UPDATE [users] SET [name]=@name, [cast]=@cast, [age]=@age WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@cast", comboBox1.SelectedItem);
            cmd.Parameters.AddWithValue("@age", numericUpDown1.Value);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                comboBox1.SelectedIndex = -1;
                numericUpDown1.Value = 0;
                MessageBox.Show("Data Update Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            Print();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM [users] WHERE [id]=@id", con);
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            int s = cmd.ExecuteNonQuery();
            con.Close();
            if (s == 1)
            {
                textBox1.Clear();
                comboBox1.SelectedIndex = -1;
                numericUpDown1.Value = 0;
                MessageBox.Show("Data Delete Successfully!");
            }
            else
            {
                MessageBox.Show("Error!");
            }
            Print();
        }

    }
}
