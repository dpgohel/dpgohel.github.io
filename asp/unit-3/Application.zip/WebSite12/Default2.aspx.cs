﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Application["Name"] != null && Application["Email"] != null)
        {
            Literal1.Text = Application["Name"].ToString();
            Literal2.Text = Application["Email"].ToString();
                
        }
        if (Session["Name"] != null && Session["Email"] != null)
        {
            Literal3.Text = Session["Name"].ToString();
            Literal4.Text = Session["Email"].ToString();
        }
        //else
        //{
        //    Literal5.Text = "Session & Application data not found";
        //}
    }
}