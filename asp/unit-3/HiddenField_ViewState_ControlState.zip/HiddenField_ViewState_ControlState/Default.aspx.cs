﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    int count = 1;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            TextBox1.Text = "0";
            TextBox2.Text = "0";
            TextBox3.Text = "0";
            TextBox4.Text = "0";
            ViewState["count"] = 0;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text = count.ToString();
        count = count + 1;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        HiddenField1.Value = (Convert.ToInt32(HiddenField1.Value) + 1).ToString();
        TextBox2.Text = HiddenField1.Value;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        //if (ViewState["count"] != null)
        //{
        //    count = Convert.ToInt32(ViewState["count"]) + 1;
        //}
        //TextBox3.Text = count.ToString();
        //ViewState["count"] = count.ToString();

        //or

        ViewState["count"] = (Convert.ToInt32(ViewState["count"]) + 1).ToString();
        TextBox3.Text = ViewState["count"].ToString();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        int cnt = Convert.ToInt32(TextBox4.Text) + 1;
        TextBox4.Text = cnt.ToString();
    }
}